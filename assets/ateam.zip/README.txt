README

Course: cs400
Semester: Fall 2019
Project name: Social Network
Team Members:
1. Yijun Cheng, lecture 001, cheng229@wisc.edu
2. Yuedong Cui, lecture 001, cui54@wisc.edu
3. Ruizhe Wang, lecture 001, rwang477@wisc.edu
4. Yuzheng Zhang, lecture 001, yzhang975@wisc.edu
5. Haolin Li, lecture 001, hli564@wisc.edu
 

Which team members were on same xteam together?
NONE


Other notes or comments to the grader:
This is a a program that displays a GUI that shows the main view that the user
will see for your program.  This is a initial view of this program, which shows
all of the users in the screen and their relationship. Later, you can click each
user to set him/her to the central user. But now, in the initial view, there is
no central user.

[place any comments or notes that will help the grader here]
In this program, we have a search bar used to search user name. "add" function 
used to add any new user or edge into the network. "remove" function used to 
remove any user or edge in the network. "Mutual Friends" used to view a list of 
mutual friends between any two users. "shortest path" used to find and display
the sequence of friends that is the shortest path between any two users within 
a connected component. "Number of groups" used to View an integer that indicates
the number of connected components (groups) in the social network. 
"Last instruction" used to display a status field that indicates what was just
done. "clean" button used to clean current network. "exit" button used to exit
the program. "save" button allowed user to save the instructions into a file.
